% This example shows how to calculate and plot both the
% fundamental TE and TM eigenmodes of an example 3-layer ridge
% waveguide using the full-vector eigenmode solver.  

% Refractive indices:
n1 = 3.34;          % Lower cladding
n2 = 3.44;          % Core
n3 = 1.00;          % Upper cladding (air)

% Layer heights:
h1 = 2.0;           % Lower cladding
h2 = 1.3;           % Core thickness
h3 = 0.5;           % Upper cladding

% Horizontal dimensions:
rh = 1.1;           % Ridge height
rw = 1.0;           % Ridge half-width
rw2 = linspace(0.325, 1, 10);
side = 1.5;         % Space on side

% Grid size:
dx = 0.1; %0.0125;        % grid size (horizontal)
dy = 0.1; %0.0125;        % grid size (vertical)

lambda = 1.55;      % vacuum wavelength
nmodes = 1;         % number of modes to compute


plot_pos = 1;
plot_pos2 = 1;
for i=1:10
    [x,y,xc,yc,nx,ny,eps,edges] = waveguidemesh([n1,n2,n3],[h1,h2,h3], ...
                                            rh,rw2(i),side,dx,dy);
    %TE mode
    [Hx,Hy,neff] = wgmodes(lambda,n2,nmodes,dx,dy,eps,'000A');
    fprintf(1,'neff(TE) = %.6f (half width = %.6f)\n',neff, rw2(i));
    figure(1);
    subplot(4, 5, plot_pos);
    plot_pos = plot_pos + 1;
    contourmode(x,y,Hx);
    title('Hx (TE mode)'); xlabel('x'); ylabel('y'); 
    for v = edges, line(v{:}); end
    subplot(4, 5, plot_pos);
    plot_pos = plot_pos + 1;
    contourmode(x,y,Hy);
    title('Hy (TE mode)'); xlabel('x'); ylabel('y'); 
    for v = edges, line(v{:}); end
    %{
    %TM plot
    [Hx,Hy,neff] = wgmodes(lambda,n2,nmodes,dx,dy,eps,'000S');
    fprintf(1,'neff(TM) = %.6f (half width = %.6f)\n',neff, rw2(i));
    figure(2);
    subplot(4, 5, plot_pos2);
    plot_pos2 = plot_pos2 + 1;
    contourmode(x,y,Hx);
    title('Hx (TM mode) half-width=', rw2(i)); xlabel('x'); ylabel('y'); 
    for v = edges, line(v{:}); end
    subplot(4, 5, plot_pos2);
    plot_pos2 = plot_pos2 + 1;
    contourmode(x,y,Hy);
    title('Hy (TM mode)half-width=', rw2(i)); xlabel('x'); ylabel('y'); 
    for v = edges, line(v{:}); end
    %}
end

