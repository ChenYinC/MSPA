% This example shows how to calculate and plot both the
% fundamental TE and TM eigenmodes of an example 3-layer ridge
% waveguide using the full-vector eigenmode solver.  

% Refractive indices:
n1 = 3.34;          % Lower cladding
n2 = 3.44;          % Core
n3 = 1.00;          % Upper cladding (air)

% Layer heights:
h1 = 2.0;           % Lower cladding
h2 = 1.3;           % Core thickness
h3 = 0.5;           % Upper cladding

% Horizontal dimensions:
rh = 1.1;           % Ridge height
rw = 1.0;           % Ridge half-width
side = 1.5;         % Space on side

% Grid size:
dx = 0.0125;        % grid size (horizontal)
dy = 0.0125;        % grid size (vertical)

lambda = 1.55;      % vacuum wavelength
nmodes = 10;         % number of modes to compute

[x,y,xc,yc,nx,ny,eps,edges] = waveguidemesh([n1,n2,n3],[h1,h2,h3], ...
                                            rh,rw,side,dx,dy); 

%calculate and plot from mode 1 to 10;
[Hx_TM,Hy_TE,neff_TE] = wgmodes(lambda,n2,nmodes,dx,dy,eps,'000A'); %TE
[Hx_TM,Hy_TM,neff_TM] = wgmodes(lambda,n2,nmodes,dx,dy,eps,'000S'); %TM
plot_pos = 1; % subplot coordinate
plot_pos2 = 1;
for i=0:(nmodes-1)
    %TE mode
    fprintf(1,'neff_TE = %.6f (mode: %d)\n',neff_TM(i+1), i+1);
    figure(1);
    subplot(4, 5,plot_pos);
    plot_pos = plot_pos + 1;
    contourmode_surf(x,y,Hx_TM(:, :, i+1));
    title('Hx (TE mode) mode: ', i+1); xlabel('x'); ylabel('y'); 
    for v = edges, line(v{:}); end
    subplot(4, 5, plot_pos);
    plot_pos = plot_pos + 1;
    contourmode_surf(x,y,Hy_TM(:, :, i+1));
    title('Hy (TE mode) mode: ', i+1); xlabel('x'); ylabel('y'); 
    for v = edges, line(v{:}); end

    %
    %TM mode
    fprintf(1,'neff_TM = %.6f (mode: %d)\n',neff_TM, i+1);
    figure(2);
    subplot(4, 5, plot_pos2);
    plot_pos2 = plot_pos2 + 1;
    contourmode_surf(x,y,Hx_TM(:, :, i+1));
    title('Hx (TM mode) mode: ', i+1); xlabel('x'); ylabel('y'); 
    for v = edges, line(v{:}); end
    subplot(4, 5, plot_pos2);
    plot_pos2 = plot_pos2 + 1;
    contourmode_surf(x,y,Hy_TM(:, :, i+1));
    title('Hy (TM mode) mode: ', i+1); xlabel('x'); ylabel('y'); 
    for v = edges, line(v{:}); end
    %}    
end

